---
name: mwg-policy-decoder
description: Decode McAfee/Skyhigh Web Gateway (MWG) proxy configuration backups (.backup files containing base64-gzip-tar'd gwrs.xml rule sets) into precise, verified, plain-language policy statements. Use whenever the user has an MWG/Skyhigh proxy backup and asks what a rule does, whether something is blocked, what triggers a policy, wants a rule "translated," "decoded," "broken down," or wants the real enforcement behavior of DLP, file-blocking, anti-malware, SSL decryption, or URL-filtering rules. Also trigger for comparing two MWG configs, producing a "line by line" listing of a rule group, or determining what attribution (user/IP/matched-content) a rule's logging captures. Do NOT trust rule/dictionary names alone -- names are frequently misleading, and whether a rule is enabled must be checked at both the group level and the individual rule level.
---

# MWG/Skyhigh Policy Decoder

Translates raw McAfee/Skyhigh Web Gateway proxy rule configs into accurate, verified plain-language (or structured) policy statements. Built from a real, extensive audit process -- every technique here exists because a shortcut version of it produced a wrong answer at least once.

**The core discipline this skill enforces: read the actual rule XML and resolve every ID to a real name before saying anything about what a rule does. Never infer behavior from a rule's name, a dictionary's name, or a summary document written about the config. Those are all frequently wrong or incomplete in ways that only show up when you check the raw config directly.**

## Step 0: Extract the raw config

MWG backups (`*.backup` files) are not directly readable. They're XML wrappers around a base64-encoded, gzip-compressed tar archive:

```python
import re, base64, gzip, tarfile, io, os

content = open('SomeProxy.backup', encoding='utf-8', errors='replace').read()
m = re.search(r'<co_backup_data>(.*?)</co_backup_data>', content, re.S)
raw = base64.b64decode(m.group(1).strip())
decompressed = gzip.decompress(raw)
tarfile.open(fileobj=io.BytesIO(decompressed)).extractall('extracted_dir')
```

This produces ~1,000-2,500 individual XML files. The two you need most:
- `gwrs.xml` (or `gwrs-fixed.xml`) -- the full rule set (rule groups, rules, conditions, actions)
- `lists/`, `lists/system_lists/`, `lists/subscribed_lists/` -- every named list/dictionary object referenced by rules
- `cfg/com.scur.engine.dlp*.xml` -- DLP dictionary/category definitions specifically (these live outside `lists/`)

**Dynamic/subscribed lists are often empty in the backup.** Check for `feature="CUSTOMER_MAINTAINED"` or `feature="MCAFEE_MAINTAINED"` on a list object with `<content/>` (empty). These pull live from a URL on a schedule (commonly every 20 min) and the backup only captures the subscription pointer, not the content. If asked to characterize one of these, say so explicitly rather than reporting it as empty/absent -- the real content exists, just not in this file. Extract the `<url>` if the user needs to fetch it themselves.

## Step 1: Never trust "enabled" from one signal alone

A rule can be disabled at the **rule** level while its parent **group** is enabled, or vice versa. Both must be checked, and the correct way to find which rules belong to which group is **depth-based tag nesting**, not "whichever group heading appeared most recently in the file" (a positional heuristic that breaks silently when groups are siblings or the file has any structural quirk).

```python
import re

def find_group_span(content, group_name):
    idx = content.find(f'name="{group_name}"')
    start = content.rfind('<ruleGroup', 0, idx)
    depth = 0
    pos = start
    pattern = re.compile(r'<ruleGroup[ >]|</ruleGroup>')
    while True:
        m = pattern.search(content, pos)
        if m.group().startswith('<ruleGroup'):
            depth += 1
        else:
            depth -= 1
            if depth == 0:
                return start, m.end()
        pos = m.end()

start, end = find_group_span(content, 'DLP in Request Cycle')
block = content[start:end]
group_enabled = re.search(r'enabled="(\w+)"', content[start:start+300]).group(1)
rules = re.findall(r'<rule id="(\d+)" enabled="(\w+)" name="([^"]*)"', block)
```

If you skip this and use a "nearest preceding `<ruleGroup>`" regex instead, verify it against at least one known case with `find_group_span` before trusting its output -- this was tried in practice and got contradicted on re-check.

**Also check for rules with the identical name/purpose living in a *different*, mutually-exclusive group** (commonly an "Audit Only" or similar shadow group). A real, recurring pattern in MWG configs: the same logical category (e.g. "Member ID") has two rule instances with the same name -- one in a blocking group, one in an audit-only group -- and exactly one of the two is enabled. Reporting only the blocking-group instance's status without checking its audit-group twin will get the enforcement status backwards.

## Step 2: Resolve every referenced ID to its real name

Conditions reference dictionaries/categories/lists by opaque ID (`configurationId="com.scur.engine.dlpdict.3050"`), never by name inline. Build a name map before rendering any rule's logic:

```python
import re, glob, json

id_to_name = {}
for f in glob.glob('extracted_dir/**/cfg/com.scur.engine.dlp*.xml', recursive=True):
    head = open(f, encoding='utf-8', errors='replace').read(500)
    idm = re.search(r'id="(com\.scur\.engine\.dlp\w+\.\d+)"', head)
    namem = re.search(r'name="([^"]*)"', head)
    if idm and namem:
        id_to_name[idm.group(1)] = namem.group(1)
```

Do the same for `lists/*.xml` and `lists/system_lists/*.xml` (media-type lists, string/regex/IP-range lists) when a rule references `listValue id="..."`.

Then render each `<conditionExpression>` with its `prefix` (AND/OR), `operatorId`, and the **resolved name** of whatever it's checking -- not the raw ID:

```python
exprs = re.findall(r'<conditionExpression.*?(?=<conditionExpression|</expressions>)', block, re.S)
for e in exprs:
    prefix = (re.search(r'prefix="(\w+)"', e) or [None,''])[1] if re.search(r'prefix="(\w+)"', e) else ''
    op = re.search(r'operatorId="([^"]*)"', e).group(1).replace('com.scur.operator.', '')
    prop = re.search(r'propertyId="([^"]*)"', e).group(1).replace('com.scur.engine.', '')
    cfg_m = re.search(r'configurationId="([^"]*)"', e)
    strval_m = re.search(r'<stringValue value="([^"]*)"', e)
    label = id_to_name.get(cfg_m.group(1), cfg_m.group(1)) if cfg_m else (strval_m.group(1) if strval_m else '')
    print(f'{prefix:<4} {prop:<35} {op:<14} {label}')
```

Watch for attribute-order variance across rules -- don't build one combined regex assuming `configurationId` always precedes `propertyId` in the tag; extract each attribute independently from the same expression block.

## Step 3: Get the actual pattern content, not just the dictionary name

A dictionary named "SSN" might use a real checksum-validated detector with no regex at all (MWG's built-in SSA-check classifier), while a dictionary named "Masked SSN" might have an actual, extractable regex. These are structurally different and behave completely differently -- always pull the literal pattern:

```python
import re, html
content = open(f'extracted_dir/.../cfg/com.scur.engine.dlpdict.{id}.xml', encoding='utf-8').read()
m = re.search(r'value="(&lt;list.*?)"\s*/>', content, re.S)
unescaped = html.unescape(m.group(1))
patterns = re.findall(r'key="word-or-regex"[^>]*value="([^"]*)"', unescaped)
```

Report the literal pattern verbatim (e.g. `[*]{3}\-[*]{2}\-\d{4}`) -- don't paraphrase it into a shorthand like "XXX-XX-XXXX" that changes the actual character class or digit count.

## Step 4: Trace what happens on match -- separately from whether it's a detector or an enforcer

Every rule has exactly one `<actionContainer actionId="com.scur.mainaction.X">`. The common values and what they actually mean:

- `block` -- stops the transaction
- `continue` -- rule fires (tags, logs, counters) but the transaction proceeds unmodified
- `stoprulegroup` -- exits the enclosing rule group early (used for both bypass/exemption rules and scope gates)

**A rule with action `continue` that "detects" something is not enforcement.** If the user asks whether a policy "blocks" something, the answer must come from a rule whose action is actually `block` -- not from a detection/tagging rule that merely sets a property. These are frequently two separate rules in two separate groups checking the *same* underlying pattern independently, not a pipeline where the detector triggers the blocker. Check whether the tagging rule's output property is read anywhere else in the ruleset before assuming it does anything beyond logging.

## Step 5: Check the log-write rule for attribution

If asked what gets attributed/recorded when a rule fires, find the corresponding `Write ... log` rule (often in a separate `*DLP Log*` or `*Log*` group) and decode its `setActionContainer` -- it's a string concatenation of resolved properties. Common fields worth checking for specifically: `auth.username`, `system.client.ip`, `system.destination.ip`, `system.url.host`, headers (`Referer`), `dlpcat.matchedcats`, and critically `dlpdict.matchedterms` -- the last one means the actual matched text gets logged, not just a boolean. Report exactly which of these are present and which aren't (e.g. there is often no dedicated filename field even when file uploads are in scope) -- don't assume a "log" rule captures everything just because it exists.

## Step 6: Present the answer in this structure

For any single rule or policy, structure the final answer as:

**Policy/Control** -- one sentence, what it's for, in plain terms (not the rule's literal name).

**How it's validated (detection mechanism)** -- the real pattern/condition, resolved names not IDs, scope (request vs. response cycle, HTTP vs HTTPS dependency on upstream decryption if relevant, file vs. body-text vs. embedded-object-in-archive), and any exclusion/de-dup logic.

**Enforcement outcome** -- the actual action (`block`/`continue`/other), and explicitly whether this specific rule enforces anything or whether enforcement (if it exists at all) lives in a separate rule.

For a full rule group (the "line by line" case), use a table: Rule ID | Name | Enabled | Condition (resolved) | Action.

If asked for a "function" framing instead of prose, use pseudocode blocks with explicit `FUNCTION:`, `SCOPE:`, `TRIGGER:`, `RETURNS:`/`ACTION:`/`SIDE-EFFECT:` fields -- keep the same underlying facts, just reformatted; do not soften or hedge claims when reformatting into a terser style.

## Common failure modes to actively guard against (all observed in practice)

- Reporting a rule as enabled/disabled based on the group only, without checking the individual rule -- or vice versa.
- Trusting a positional "nearest preceding group" heuristic for group membership instead of real tag-depth nesting.
- Treating a `continue`-action detection rule as if it were the enforcement point.
- Assuming a dictionary's name describes its actual pattern (verify the literal regex/word list every time).
- Reporting a count (list entries, extension counts, rule counts) without actually counting -- grep/regex-count directly rather than estimating from a partial view.
- Only checking one of two proxies/configs when the user has provided both -- their DLP/file-blocking/SSL structures are frequently genuinely different, not mirrors, even when named identically.
- Stopping at keyword-search results ("does this mention encryption") instead of enumerating the full rule group and checking every rule's actual condition -- keyword search finds what you already guessed to look for and nothing else.
